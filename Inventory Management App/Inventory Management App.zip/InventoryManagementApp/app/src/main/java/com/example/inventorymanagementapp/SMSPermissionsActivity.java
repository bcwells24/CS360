package com.example.inventorymanagementapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SMSPermissionsActivity extends AppCompatActivity {

    // UI elements
    private EditText phoneNumberEditText;
    private ToggleButton smsPermissionToggle;
    private TextView permissionStatusTextView;
    private ImageButton returnButton;
    private Button logoutButton;
    // SharedPreferences to save user preferences
    private SharedPreferences sharedPreferences;

    // Constants for SharedPreferences file and keys
    private static final String PREFS_NAME = "SMSPrefs";
    private static final String KEY_PHONE_NUMBER = "phone_number";
    private static final String KEY_SMS_PERMISSION = "sms_permission";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permissions);

        // Initialize the UI elements
        initializeViews();

        // Setup SharedPreferences for storing and retrieving user data
        setupSharedPreferences();

        // Load saved preferences (phone number and SMS permission status)
        loadPreferences();

        // Set up event listeners for buttons and toggles
        setupListeners();
    }

    // Method to initialize views from the layout
    private void initializeViews() {
        phoneNumberEditText = findViewById(R.id.editTextPhoneNumber);       // Input field for phone number
        smsPermissionToggle = findViewById(R.id.toggleButtonSmsPermission); // Toggle button for SMS permission
        permissionStatusTextView = findViewById(R.id.textViewPermissionStatus); // TextView to show permission status
        returnButton = findViewById(R.id.returnButton);                     // Button to return to the previous screen
        logoutButton = findViewById(R.id.logoutButton);                     // Button to log out and navigate to MainActivity
    }

    // Setup SharedPreferences for storing user preferences
    private void setupSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    // Set up listeners for user interaction with the UI
    private void setupListeners() {
        // Listener for the SMS permission toggle button
        smsPermissionToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Validate phone number when enabling SMS permission
            if (isChecked && !isValidPhoneNumber()) {
                // Disable toggle if phone number is invalid and show a message
                smsPermissionToggle.setChecked(false);
                Toast.makeText(this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
                return;
            }
            // Save preferences after toggle action
            savePreferences(isChecked);
            // Update the displayed permission status
            updatePermissionStatus(isChecked);

            // Display confirmation toast based on SMS permission status
            if (isChecked) {
                Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
            }
        });

        // Listener for the logout button
        logoutButton.setOnClickListener(v -> {
            // Start MainActivity on logout
            startActivity(new Intent(SMSPermissionsActivity.this, MainActivity.class));
        });

        // Listener for the return button (finish activity and go back)
        returnButton.setOnClickListener(v -> finish());
    }

    // Load saved preferences (phone number and SMS permission status)
    private void loadPreferences() {
        // Retrieve phone number and SMS permission from SharedPreferences
        String phoneNumber = sharedPreferences.getString(KEY_PHONE_NUMBER, "");
        boolean smsPermission = sharedPreferences.getBoolean(KEY_SMS_PERMISSION, false);

        // Set phone number and SMS permission toggle based on saved preferences
        phoneNumberEditText.setText(phoneNumber);
        smsPermissionToggle.setChecked(smsPermission);
        // Update the displayed permission status
        updatePermissionStatus(smsPermission);
    }

    // Save preferences for phone number and SMS permission status
    private void savePreferences(boolean smsPermission) {
        // Use SharedPreferences.Editor to save data
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_PHONE_NUMBER, phoneNumberEditText.getText().toString().trim()); // Save phone number
        editor.putBoolean(KEY_SMS_PERMISSION, smsPermission);                               // Save SMS permission status
        editor.apply(); // Apply changes
    }

    // Update the displayed permission status based on SMS permission toggle
    private void updatePermissionStatus(boolean isGranted) {
        permissionStatusTextView.setText(isGranted ? "Permission Status: Granted" : "Permission Status: Denied");
    }

    // Validate the entered phone number using standard Android phone number patterns
    private boolean isValidPhoneNumber() {
        String phoneNumber = phoneNumberEditText.getText().toString().trim();
        // Check if phone number is not empty and matches a valid phone number pattern
        return !TextUtils.isEmpty(phoneNumber) && android.util.Patterns.PHONE.matcher(phoneNumber).matches();
    }
}
