package com.example.inventorymanagementapp;

import android.telephony.SmsManager;
import android.util.Log;

public class SMSManager {
    // Log tag for SMSManager
    private static final String TAG = "SMSManager";

    // Method to send an SMS message
    public static boolean sendSMS(String phoneNumber, String message) {
        // Validate phone number and check if message is empty
        if (!isValidPhoneNumber(phoneNumber) || message == null || message.isEmpty()) {
            Log.e(TAG, "Invalid phone number or empty message"); // Log an error if validation fails
            return false; // Return false indicating failure
        }

        try {
            // Get an instance of the SmsManager to send the SMS
            SmsManager smsManager = SmsManager.getDefault();
            // Send the text message to the provided phone number
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.d(TAG, "SMS sent successfully to " + phoneNumber); // Log success message
            return true; // Return true indicating successful SMS sending
        } catch (Exception e) {
            // Log any exceptions that occur during SMS sending
            Log.e(TAG, "Failed to send SMS: " + e.getMessage(), e);
            return false; // Return false indicating failure
        }
    }

    // Private method to validate the phone number format
    private static boolean isValidPhoneNumber(String phoneNumber) {
        // Check if phone number is non-null and matches the standard phone number pattern
        return phoneNumber != null && android.util.Patterns.PHONE.matcher(phoneNumber).matches();
    }
}
