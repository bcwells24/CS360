package com.example.inventorymanagementapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    // Declare EditText views for username and password input
    private EditText usernameEditText;
    private EditText passwordEditText;

    // Instance of DatabaseHelper to handle user registration
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize DatabaseHelper instance
        databaseHelper = new DatabaseHelper(this);

        // Initialize EditText views for capturing user input
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Initialize register button and go back button
        Button registerButton = findViewById(R.id.registerButton);
        Button goBackButton = findViewById(R.id.goBackButton);

        // Set an onClickListener to handle user registration when the button is clicked or go back
        registerButton.setOnClickListener(v -> registerUser());
        goBackButton.setOnClickListener(v -> finish());

    }

    // Method to handle user registration logic
    private void registerUser() {
        // Get input from EditText fields and trim any leading/trailing spaces
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Check if username or password fields are empty
        if (username.isEmpty() || password.isEmpty()) {
            // Show a toast message if either field is empty
            Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to register the user in the database
        boolean isSuccess = databaseHelper.registerUser(username, password);

        // Check if the registration was successful
        if (isSuccess) {
            // Show success message and close the activity to return to MainActivity
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
            finish(); // Finish this activity and return to MainActivity
        } else {
            // Show failure message if registration was not successful
            Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
        }
    }
}
