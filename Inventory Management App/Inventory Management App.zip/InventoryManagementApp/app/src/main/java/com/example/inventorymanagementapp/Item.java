package com.example.inventorymanagementapp;

/**
 * Represents an inventory item with properties like ID, name, quantity, and date added.
 */
public class Item {

    private final int id; // Unique identifier for the item
    private String name; // Name of the item
    private int quantity; // Quantity of the item in inventory
    private final String dateAdded; // Date the item was added to the inventory

    /**
     * Constructor for creating an Item object.
     *
     * @param id        Unique identifier for the item
     * @param name      Name of the item
     * @param quantity  Initial quantity of the item
     * @param dateAdded Date when the item was added
     */
    public Item(int id, String name, int quantity, String dateAdded) {
        this.id = id; // Set the item's ID
        this.name = name; // Set the item's name
        this.quantity = quantity; // Set the item's initial quantity
        this.dateAdded = dateAdded; // Set the date the item was added
    }

    /**
     * Gets the unique identifier of the item.
     *
     * @return The item's ID
     */
    public int getId() {
        return id; // Return the item's ID
    }

    /**
     * Gets the name of the item.
     *
     * @return The item's name
     */
    public String getName() {
        return name; // Return the item's name
    }

    /**
     * Gets the quantity of the item.
     *
     * @return The item's quantity
     */
    public int getQuantity() {
        return quantity; // Return the item's quantity
    }

    /**
     * Gets the date when the item was added to inventory.
     *
     * @return The date the item was added
     */
    public String getDateAdded() {
        return dateAdded; // Return the date added
    }

    /**
     * Updates the quantity of the item.
     *
     * @param quantity The new quantity to set for the item
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity; // Update the item's quantity
    }

    /**
     * Updates the name of the item.
     *
     * @param name The new name to set for the item
     */
    public void setName(String name) {
        this.name = name; // Update the item's name
    }
}
