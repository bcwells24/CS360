package com.example.inventorymanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    // Declare EditText fields for item name and quantity input
    private EditText itemNameEditText, itemQuantityEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        // Initialize UI components (EditText fields and Button)
        itemNameEditText = findViewById(R.id.itemNameEditText);
        itemQuantityEditText = findViewById(R.id.itemQuantityEditText);
        Button saveItemButton = findViewById(R.id.saveItemButton);

        // Set up listener for the save button click event
        saveItemButton.setOnClickListener(v -> addItemToInventory());
    }

    // Method to handle adding the item to the inventory
    private void addItemToInventory() {
        // Get user input for item name and quantity
        String itemName = itemNameEditText.getText().toString();
        String itemQuantityStr = itemQuantityEditText.getText().toString();
        String itemDate = getCurrentDate(); // Get current date

        // Validate input: ensure both item name and quantity are entered
        if (itemName.isEmpty() || itemQuantityStr.isEmpty()) {
            Toast.makeText(this, "Please enter both item name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int itemQuantity;
        try {
            // Try to convert the quantity input to an integer
            itemQuantity = Integer.parseInt(itemQuantityStr);
        } catch (NumberFormatException e) {
            // Show an error message if the quantity is not a valid number
            Toast.makeText(this, "Please enter a valid quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        // Initialize DatabaseHelper to interact with the database
        DatabaseHelper dbHelper = new DatabaseHelper(this);

        // Check if the item already exists in the database
        Item existingItem = dbHelper.getItemByName(itemName); // You will need to implement getItemByName method in DatabaseHelper

        boolean success;
        if (existingItem != null) {
            // If the item exists, update its quantity
            success = dbHelper.updateItemQuantity(existingItem.getId(), itemQuantity);
            Toast.makeText(this, "Item quantity updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            // If the item doesn't exist, add a new item
            success = dbHelper.addItem(itemName, itemQuantity, itemDate);
            Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
        }

        if (success) {
            // If the operation is successful, navigate back to the OverviewActivity
            Intent intent = new Intent(AddItemActivity.this, OverviewActivity.class);
            startActivity(intent);
            finish();
        } else {
            // Show an error message if the operation fails
            Toast.makeText(this, "Failed to add or update item", Toast.LENGTH_SHORT).show();
        }

        // Go back to the OverviewActivity regardless
        Intent intent = new Intent(AddItemActivity.this, OverviewActivity.class);
        startActivity(intent);
        finish();
    }

    // Method to get the current date in "yyyy-MM-dd" format
    private String getCurrentDate() {
        Calendar calendar = Calendar.getInstance(); // Get the current date
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()); // Set date format
        return sdf.format(calendar.getTime()); // Return formatted date
    }
}
