package com.example.inventorymanagementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Constants for database name and version
    private static final String DATABASE_NAME = "inventoryDB";
    private static final int DATABASE_VERSION = 1;

    // Constants for table names
    private static final String TABLE_INVENTORY = "inventory";
    private static final String TABLE_USERS = "users";

    // Constants for inventory table columns
    public static final String COLUMN_ITEM_ID = "id";
    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";
    public static final String COLUMN_ITEM_DATE = "date";

    // Constants for users table columns
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USER_NAME = "username";
    private static final String COLUMN_USER_PASSWORD = "password";

    private static final String TAG = "DatabaseHelper"; // For logging

    private final Context context; // Reference to the context

    // Constructor
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create the inventory table
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "(" +
                COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_ITEM_NAME + " TEXT NOT NULL, " +
                COLUMN_ITEM_QUANTITY + " INTEGER NOT NULL, " +
                COLUMN_ITEM_DATE + " TEXT NOT NULL" + ")";

        // SQL statement to create the users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "(" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_NAME + " TEXT NOT NULL UNIQUE, " +
                COLUMN_USER_PASSWORD + " TEXT NOT NULL" + ")";

        // Execute the SQL statements
        db.execSQL(CREATE_INVENTORY_TABLE);
        db.execSQL(CREATE_USERS_TABLE);
    }

    // Called when the database needs to be upgraded (e.g., version change)
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the old tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        // Recreate the tables
        onCreate(db);
    }

    // Method to add an item to the inventory table
    public boolean addItem(String name, int quantity, String dateAdded) {
        SQLiteDatabase db = this.getWritableDatabase(); // Get writable database
        ContentValues values = new ContentValues(); // Prepare content values
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        values.put(COLUMN_ITEM_DATE, dateAdded);

        // Insert the item and return success status
        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1;
    }

    // Method to update the quantity of an item
    public boolean updateItemQuantity(int itemId, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_QUANTITY, newQuantity);

        // Update the quantity and notify if it reaches zero
        int rowsAffected = db.update(TABLE_INVENTORY, values, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(itemId)});
        if (rowsAffected > 0 && newQuantity == 0) {
            notifyZeroQuantity(itemId); // Call method to notify zero quantity
        }

        return rowsAffected > 0; // Return true if the update was successful
    }

    // Method to notify when an item reaches zero quantity
    private void notifyZeroQuantity(int itemId) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("SMSPrefs", Context.MODE_PRIVATE);
        boolean smsEnabled = sharedPreferences.getBoolean("sms_permission", false); // Check if SMS permission is enabled
        String phoneNumber = sharedPreferences.getString("phone_number", ""); // Get the phone number

        if (smsEnabled && !phoneNumber.isEmpty()) {
            // If SMS is enabled and phone number is available, send notification
            String itemName = getItemNameById(itemId); // Get item name by ID
            if (itemName != null) {
                SMSManager.sendSMS(phoneNumber, "Item: " + itemName + " has reached zero quantity.");
            }
        }
    }

    // Method to fetch all items from the inventory table
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase(); // Get readable database
        Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, null); // Query all items

        if (cursor.moveToFirst()) {
            // Loop through the result set and create item objects
            do {
                try {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME));
                    int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
                    String dateAdded = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DATE));

                    Item item = new Item(id, name, quantity, dateAdded); // Create a new Item object
                    itemList.add(item); // Add item to the list
                } catch (IllegalArgumentException e) {
                    Log.e(TAG, "Error fetching data: " + e.getMessage()); // Log any error during data fetching
                }
            } while (cursor.moveToNext()); // Move to the next row
        }
        cursor.close(); // Close the cursor
        return itemList; // Return the list of items
    }

    // Method to fetch an item by name from the inventory table
    public Item getItemByName(String name) {
        SQLiteDatabase db = this.getReadableDatabase(); // Get readable database
        Cursor cursor = db.query(TABLE_INVENTORY, null, COLUMN_ITEM_NAME + "=?", new String[]{name}, null, null, null); // Query item by name
        Item item = null;
        if (cursor != null && cursor.moveToFirst()) {
            // If item is found, create an Item object
            item = new Item(
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_DATE))
            );
            cursor.close(); // Close the cursor
        }
        return item; // Return the item object
    }

    // Method to delete an item from the inventory table
    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase(); // Get writable database
        db.delete(TABLE_INVENTORY, COLUMN_ITEM_ID + " = ?", new String[]{String.valueOf(id)}); // Delete item by ID
    }

    // Method to register a new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, username);
        values.put(COLUMN_USER_PASSWORD, password);

        // Insert the user and return success status
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Method to authenticate a user during login
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase(); // Get readable database
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USER_NAME + " = ? AND " + COLUMN_USER_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password}); // Query the user with given credentials

        boolean isAuthenticated = cursor != null && cursor.moveToFirst(); // Check if the user exists
        if (cursor != null) {
            cursor.close(); // Close the cursor
        }
        return isAuthenticated; // Return authentication result
    }

    // Method to fetch an item name by its ID
    private String getItemNameById(int itemId) {
        SQLiteDatabase db = this.getReadableDatabase(); // Get readable database
        Cursor cursor = db.query(TABLE_INVENTORY, new String[]{COLUMN_ITEM_NAME}, COLUMN_ITEM_ID + "=?", new String[]{String.valueOf(itemId)}, null, null, null);
        String itemName = null;
        if (cursor != null && cursor.moveToFirst()) {
            itemName = cursor.getString(0); // Get item name from the cursor
            cursor.close(); // Close the cursor
        }
        return itemName; // Return the item name
    }
}
