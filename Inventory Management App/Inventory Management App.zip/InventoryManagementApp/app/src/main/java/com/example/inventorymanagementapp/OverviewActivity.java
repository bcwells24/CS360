package com.example.inventorymanagementapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * OverviewActivity class handles the main inventory display and user interactions
 * for adding items, accessing settings, and managing SMS notifications.
 * It also checks SMS permission and prompts the user if the permission is not granted.
 */
public class OverviewActivity extends AppCompatActivity {

    // Request code for SMS permission
    private static final int REQUEST_SMS_PERMISSION = 123;
    // SharedPreferences keys for storing SMS permission state
    private static final String PREFS_NAME = "SMSPrefs";
    private static final String KEY_SMS_PERMISSION = "sms_permission";

    // UI components and data variables
    private RecyclerView inventoryRecyclerView;
    private InventoryAdapter inventoryAdapter;
    private DatabaseHelper databaseHelper;
    private List<Item> itemList;
    private Button addItemButton;
    private ImageButton settingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_overview);

        initializeViews();      // Initialize UI components
        setupRecyclerView();    // Set up RecyclerView for displaying inventory
        setupListeners();       // Set click listeners for buttons
    }

    /**
     * Initialize UI components.
     */
    private void initializeViews() {
        // Find RecyclerView and buttons in the layout
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        settingsButton = findViewById(R.id.settingsButton);
    }

    /**
     * Set up the RecyclerView with the InventoryAdapter and link it to the database.
     */
    private void setupRecyclerView() {
        // Initialize the database helper and item list
        databaseHelper = new DatabaseHelper(this);
        itemList = new ArrayList<>();
        // Set up the adapter and layout manager for the RecyclerView
        inventoryAdapter = new InventoryAdapter(itemList, this, databaseHelper);
        inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        inventoryRecyclerView.setAdapter(inventoryAdapter);
    }

    /**
     * Set up click listeners for the Add Item and Settings buttons.
     */
    private void setupListeners() {
        // Navigate to AddItemActivity when Add Item button is clicked
        addItemButton.setOnClickListener(v -> startActivity(new Intent(OverviewActivity.this, AddItemActivity.class)));

        // Navigate to SMSPermissionsActivity when Settings button is clicked
        settingsButton.setOnClickListener(v -> startActivity(new Intent(OverviewActivity.this, SMSPermissionsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();             // Reload inventory items when the activity resumes
        checkSmsPermissionState(); // Check and update SMS permission state
    }

    /**
     * Checks if SMS permission is enabled and prompts the user if necessary.
     * Updates the InventoryAdapter to handle SMS-specific functionality.
     */
    private void checkSmsPermissionState() {
        // Get the SMS permission state from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isSmsEnabled = sharedPreferences.getBoolean(KEY_SMS_PERMISSION, false);

        // Pass the SMS permission state to the adapter
        inventoryAdapter.setSmsEnabled(isSmsEnabled);

        // Show permission dialog if SMS notifications are not enabled
        if (!isSmsEnabled) {
            showSmsPermissionDialog();
        }
    }

    /**
     * Loads inventory items from the database and updates the RecyclerView.
     */
    private void loadItems() {
        // Clear the existing item list and reload from the database
        itemList.clear();
        itemList.addAll(databaseHelper.getAllItems());
        inventoryAdapter.notifyDataSetChanged(); // Notify adapter of data change
    }

    /**
     * Checks if SMS permission is granted, and requests it if necessary.
     * If permission is granted, sends an SMS notification.
     *
     * @param itemName The name of the item that reached zero quantity.
     * @param phoneNumber The phone number to send the notification to.
     */
    public void checkAndRequestSmsPermission(String itemName, String phoneNumber) {
        // Check if the SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request SMS permission if not already granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        } else {
            // Send SMS if permission is already granted
            sendSmsNotification(phoneNumber, itemName);
        }
    }

    /**
     * Displays a dialog to the user, prompting them to enable SMS notifications.
     */
    private void showSmsPermissionDialog() {
        // Create and show an AlertDialog prompting the user to enable SMS notifications
        new AlertDialog.Builder(this)
                .setTitle("Enable SMS Notifications")
                .setMessage("To receive alerts when an item reaches zero quantity, please enable SMS notifications in the settings.")
                .setPositiveButton("Go to Settings", (dialog, which) -> {
                    // Launch SMSPermissionsActivity when user chooses to go to settings
                    Intent intent = new Intent(OverviewActivity.this, SMSPermissionsActivity.class);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // Dismiss the dialog if user chooses to cancel
                    dialog.dismiss();
                })
                .show();
    }

    /**
     * Sends an SMS notification to the specified phone number when an item's quantity reaches zero.
     *
     * @param phoneNumber The recipient's phone number.
     * @param itemName The name of the item that reached zero quantity.
     */
    private void sendSmsNotification(String phoneNumber, String itemName) {
        if (phoneNumber != null && !phoneNumber.isEmpty()) {
            // Construct the SMS message
            String message = "Item: " + itemName + " has reached zero quantity.";
            // Attempt to send the SMS and provide feedback to the user
            boolean success = SMSManager.sendSMS(phoneNumber, message);
            if (success) {
                Toast.makeText(this, "SMS sent successfully.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
