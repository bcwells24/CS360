package com.example.inventorymanagementapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * Adapter for displaying inventory items in a RecyclerView.
 * Handles binding data to the view and managing item interactions.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    private final List<Item> itemList; // List of items to display
    private final DatabaseHelper databaseHelper; // Database helper for data operations
    private final Context context; // Context for accessing resources
    private boolean isSmsEnabled; // Flag to determine if SMS notifications are enabled

    /**
     * Constructor for InventoryAdapter.
     *
     * @param itemList       List of items to be displayed
     * @param context        Context for layout inflation
     * @param databaseHelper Database helper for database operations
     */
    public InventoryAdapter(List<Item> itemList, Context context, DatabaseHelper databaseHelper) {
        this.itemList = itemList; // Initialize item list
        this.context = context; // Initialize context
        this.databaseHelper = databaseHelper; // Initialize database helper
    }

    /**
     * Sets the SMS notification status and notifies the adapter to refresh the view.
     *
     * @param isEnabled True if SMS notifications are enabled; false otherwise
     */
    public void setSmsEnabled(boolean isEnabled) {
        this.isSmsEnabled = isEnabled; // Update SMS status
        notifyDataSetChanged(); // Refresh the RecyclerView
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout for each inventory item
        View itemView = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new InventoryViewHolder(itemView); // Return a new ViewHolder instance
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        Item item = itemList.get(position); // Get the item at the current position
        holder.itemName.setText(item.getName()); // Set item name
        holder.itemQuantity.setText(String.valueOf(item.getQuantity())); // Set item quantity
        holder.itemDateAdded.setText(item.getDateAdded()); // Set date added

        // Setup quantity buttons and delete button functionality
        setupQuantityButtons(holder, item);
        setupDeleteButton(holder, position);
    }

    /**
     * Configures the quantity adjustment buttons for the item.
     *
     * @param holder The ViewHolder containing the item views
     * @param item   The current item
     */
    private void setupQuantityButtons(InventoryViewHolder holder, Item item) {
        // Add quantity button listener
        holder.buttonAddQuantity.setOnClickListener(v -> updateQuantity(holder, item, item.getQuantity() + 1));
        // Subtract quantity button listener with validation
        holder.buttonSubtractQuantity.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() - 1;
            if (newQuantity >= 0) {
                updateQuantity(holder, item, newQuantity);
            }
        });
    }

    /**
     * Updates the quantity of the item and the database.
     *
     * @param holder      The ViewHolder containing the item views
     * @param item        The item being updated
     * @param newQuantity The new quantity value
     */
    private void updateQuantity(InventoryViewHolder holder, Item item, int newQuantity) {
        item.setQuantity(newQuantity); // Update the item's quantity
        databaseHelper.updateItemQuantity(item.getId(), newQuantity); // Update quantity in the database
        holder.itemQuantity.setText(String.valueOf(newQuantity)); // Update the displayed quantity

        // Check for SMS notification conditions
        if (newQuantity == 0 && isSmsEnabled && context instanceof OverviewActivity) {
            ((OverviewActivity) context).checkAndRequestSmsPermission(item.getName(), getPhoneNumber());
        }
    }

    /**
     * Configures the delete button functionality for the item.
     *
     * @param holder   The ViewHolder containing the item views
     * @param position The position of the item in the list
     */
    private void setupDeleteButton(InventoryViewHolder holder, int position) {
        holder.buttonDeleteItem.setOnClickListener(v -> {
            databaseHelper.deleteItem(itemList.get(position).getId()); // Delete item from the database
            itemList.remove(position); // Remove item from the list
            notifyItemRemoved(position); // Notify adapter about the removed item
        });
    }

    /**
     * Retrieves the phone number from SharedPreferences for SMS notifications.
     *
     * @return The phone number as a String
     */
    private String getPhoneNumber() {
        // Implement this method to retrieve the phone number from SharedPreferences
        return ""; // Placeholder return statement
    }

    @Override
    public int getItemCount() {
        return itemList.size(); // Return the total number of items
    }

    /**
     * ViewHolder class for holding item views.
     */
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQuantity, itemDateAdded; // Views for item properties
        ImageButton buttonAddQuantity, buttonSubtractQuantity, buttonDeleteItem; // Buttons for item actions

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize views using itemView
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            itemDateAdded = itemView.findViewById(R.id.itemDateAdded);
            buttonAddQuantity = itemView.findViewById(R.id.buttonAddQuantity);
            buttonSubtractQuantity = itemView.findViewById(R.id.buttonSubtractQuantity);
            buttonDeleteItem = itemView.findViewById(R.id.buttonDeleteItem);
        }
    }
}
