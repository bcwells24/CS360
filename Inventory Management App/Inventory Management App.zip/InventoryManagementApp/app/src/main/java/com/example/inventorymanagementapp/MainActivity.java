package com.example.inventorymanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity class that handles user login and navigation to the registration page.
 * This is the entry point of the application where users can log in or register.
 */
public class MainActivity extends AppCompatActivity {

    // DatabaseHelper instance to manage user authentication
    private DatabaseHelper db;

    // UI components for user input fields
    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize DatabaseHelper for user authentication
        db = new DatabaseHelper(this);

        // Initialize UI components for username and password inputs
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button loginButton = findViewById(R.id.loginButton);
        Button registerButton = findViewById(R.id.registerButton);

        // Set click listener for the login button to handle user login
        loginButton.setOnClickListener(v -> {
            handleLogin(); // Calls method to handle login logic
        });

        // Set click listener for the registration button to navigate to RegisterActivity
        registerButton.setOnClickListener(v -> {
            // Start RegisterActivity to allow user registration
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    /**
     * Handles the login process by validating the username and password.
     * If authentication is successful, the user is redirected to the inventory overview screen.
     * If the credentials are invalid, an error message is shown.
     */
    private void handleLogin() {
        // Get username and password from the input fields
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Validate credentials using DatabaseHelper
        if (db.authenticateUser(username, password)) {
            // If login is successful, navigate to the inventory overview screen
            Intent intent = new Intent(MainActivity.this, OverviewActivity.class);
            startActivity(intent);
            finish(); // End MainActivity to prevent returning to login screen
        } else {
            // If credentials are invalid, show a toast message
            Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }
}
